import { 
  ShoppingCart, 
  MessageCircle, 
  Timer, 
  Truck, 
  Zap, 
  ShieldCheck, 
  Heart, 
  MapPin, 
  Quote, 
  CheckCircle2,
  Menu as MenuIcon,
  X
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

const WHATSAPP_NUMBER = "5524999999999"; // Placeholder for Angra region
const WHATSAPP_LINK = `https://wa.me/${WHATSAPP_NUMBER}?text=Olá! Gostaria de fazer um pedido na Divina Pizza.`;
const IFOOD_LINK = "https://www.ifood.com.br";

const MENU_ITEMS = [
  {
    id: 1,
    name: "Calabresa",
    price: 42,
    description: "Molho artesanal, mozzarella, calabresa fatiada e cebola roxa.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDLCDdy71nEKpNJqDMY_EdJ52BHd7DwxFsF2yP3-UQGcoKOOBHkt52hoKQk69PNS97UFllhMNCna_ItYTAuR6IsHsO432aQCSwXe1ru0cbdY6bkJPwXUFTplkZzveluk8_cL5Jumc95bDJpc9NRPrI5ELJZe6s_yc4Ge7RPEu9rQ3EWRYbkrhJLOTbWCb2DgCUTwJsSV_dtrm1qWR25Dm7TOC2ed5h3TAPLq84yc8yU7cx0zn7r8-q92DPSQTnUNTc4JeCcskWg7CA",
    tag: "Favorita",
    category: "Tradicionais"
  },
  {
    id: 2,
    name: "Frango com Catupiry",
    price: 48,
    description: "Frango desfiado temperado com o legítimo Catupiry cremoso.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDiaao5_z83cl5FW4W2xX4cKz06aM2lTVUbTUjXU5_qV68e3gw4EGyX4jf0fPaABjvtTWGbnMwgFKuR4CFNWBeG-SICZNls7QR79s1wq5hUPmPBie2Vyftj1Ilp-d4p8TcDIia14Fxai7ghvqMu1EN2MHc2X0GUZnIqCRvlvqJZX_R4QB9rc7KuYW-K8V0fMDr7wK8Py4OXJjIywLzAcXZ-FcDBjPny8jwmRc2XGsWKWdeS3SarZ9fWYoR_tzSuriEfNFzq1q72I3s",
    category: "Tradicionais"
  },
  {
    id: 3,
    name: "4 Queijos",
    price: 52,
    description: "Mozzarella, parmesão, provolone e gorgonzola selecionados.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCl4xHA4yXCR2Af8Jdw8d62XqTO4m0IGYjvEFFF7BeIa_4M83gUnG7LbV1d-RRkKpw1ZupZn3d2XQ7fsrBdxhZr9Yw07C3UAtwyKzG9rFvL1eSfKGFerNvdf9X9_s8__CDNN0MU99h5PX4uYEEL85xZ32-0BZwQQF5SThODvGub5rC6ZIRGcjN8tWmJii-ECo37vQoZvm9hwjZalfJsS215xvygt_zkNRzbBmKQDxYXTT3itZYHnsUXkYVBdgDFqecxmggMDG7lmZ8",
    category: "Especiais"
  },
  {
    id: 4,
    name: "Divina Especial",
    price: 65,
    description: "Presunto parma, rúcula fresca, tomate seco e redução de balsâmico.",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBhMvdnd7vUlxZ5H3JCto1sDBU09uiNcpiayFIp7u674H2dxEK7lvVVZNwfG4FNplefl_t3o685uvRdGl4PIbyENvI5-me0ixpmvgZg40x6rFjCBohTbxQcxeo67p3J8ivrCt0JYZvr9RRjzWg6szfzCGJmC00wry2U20QdHJKjHJomyFBpeKpzyfJHSa7lfJflA-t0Md0-w2_SfzlpRi1FeNTd6oBu4pgB6HH1iCMjlYxEap6okN8ElJmHk5Jb8eUZgyyv6WY_MAI",
    tag: "Premium",
    category: "Premium"
  }
];

export default function App() {
  const [activeCategory, setActiveCategory] = useState("Todos");
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const filteredMenu = activeCategory === "Todos" 
    ? MENU_ITEMS 
    : MENU_ITEMS.filter(item => item.category === activeCategory);

  return (
    <div className="min-h-screen bg-surface selection:bg-primary-container selection:text-white">
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'glass-nav py-3' : 'bg-transparent py-6'}`}>
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <div className="text-2xl font-black text-primary-container italic font-headline cursor-pointer">
            Divina Pizza
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            {['Menu', 'Promoções', 'Entrega', 'Sobre Nós'].map((item) => (
              <a 
                key={item}
                href={`#${item.toLowerCase().replace(' ', '-')}`}
                className="font-headline font-bold tracking-tight text-on-surface hover:text-primary transition-colors"
              >
                {item}
              </a>
            ))}
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => window.open(WHATSAPP_LINK, '_blank')}
              className="bg-primary-container text-white px-6 py-2 rounded-xl font-headline font-bold hover:scale-105 transition-transform duration-200 shadow-lg shadow-primary-container/20"
            >
              Pedir Agora
            </button>
            <button 
              className="md:hidden text-on-surface"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={28} /> : <MenuIcon size={28} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="md:hidden absolute top-full left-0 w-full bg-surface-container-high border-t border-outline-variant/20 p-6 flex flex-col gap-4"
            >
              {['Menu', 'Promoções', 'Entrega', 'Sobre Nós'].map((item) => (
                <a 
                  key={item}
                  href={`#${item.toLowerCase().replace(' ', '-')}`}
                  className="font-headline font-bold text-lg text-on-surface"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item}
                </a>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <header className="relative min-h-screen flex items-center pt-20 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            className="w-full h-full object-cover opacity-40" 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuCR6n6h_9p6G8M3-11oA_8wqgNcUdzmIvVB7-EKFTIUyeuiKrBTYES8dyzdt62CSnCtXQj7KH_oqq49QOlC5OBxp3yZDZL81Jkbo2tAcn21T_aYiyR1scM51vVlAR9nsR0USh_50qIC9UcYpA5DzQ2LQMQ4-keAJLMcZKqIK1i7diA0shYGGlSSUlQDKBlvjvDzqkiMqhxuU1bQie63uLfMgAMiTYNm_PKBwXeIZWtRFF13JBKffWyqt9n7RU3Bd2dJ-YZT6HlPEKw"
            alt="Hero Pizza"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-surface via-surface/80 to-transparent"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary-container/10 border border-secondary-container/30 text-secondary-container">
              <Zap size={16} className="fill-current" />
              <span className="font-label text-xs font-bold uppercase tracking-widest">Sabor Inesquecível</span>
            </div>
            
            <h1 className="text-6xl md:text-8xl font-headline font-black leading-tight tracking-tighter text-on-surface">
              A pizza mais <span className="text-primary-container">divina</span> de Angra.
            </h1>
            
            <p className="text-xl text-on-surface-variant max-w-lg leading-relaxed">
              Direto na sua casa. Entrega rápida no Camorim Grande e região. Massa leve, recheio generoso e ingredientes selecionados.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <button 
                onClick={() => window.open(IFOOD_LINK, '_blank')}
                className="pizza-gradient text-white px-8 py-4 rounded-xl flex items-center justify-center gap-3 font-headline font-bold text-lg shadow-xl shadow-primary-container/20 hover:scale-105 transition-transform"
              >
                <ShoppingCart size={20} />
                Pedir pelo iFood
              </button>
              <button 
                onClick={() => window.open(WHATSAPP_LINK, '_blank')}
                className="bg-tertiary-container text-on-tertiary-container px-8 py-4 rounded-xl flex items-center justify-center gap-3 font-headline font-bold text-lg hover:scale-105 transition-transform"
              >
                <MessageCircle size={20} />
                WhatsApp
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-6 pt-8 border-t border-outline-variant/30">
              <div className="flex items-center gap-2">
                <Timer size={20} className="text-secondary-container" />
                <span className="font-label font-bold">Entrega em até 45 min</span>
              </div>
              <div className="flex items-center gap-2">
                <Truck size={20} className="text-secondary-container" />
                <span className="font-label font-bold text-secondary-container">Frete Grátis*</span>
              </div>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, scale: 0.8, rotate: 10 }}
            whileInView={{ opacity: 1, scale: 1, rotate: 3 }}
            transition={{ duration: 1 }}
            className="hidden lg:block relative"
          >
            <div className="absolute -top-12 -right-12 w-64 h-64 bg-primary-container/20 blur-3xl rounded-full"></div>
            <img 
              className="relative z-10 rounded-2xl shadow-2xl hover:rotate-0 transition-transform duration-500" 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuAZOTnbkmsqNWtXhxLZco28drmbSqYhvJTG2W4IeMvnV6UocHIc4lRO-Pzn_AbceXd3XyQqi4uSpWa0N3i3aapzJVYZaDostDdT-oFZTGCP9xKVBzLxRTWtvp2U8ptXYlWyjDaLeUzvxNAaQuSakNwpZadnokRU3i2iJWNaOK_xiTlhU-A9Se_1kRCmAHFciQdFr3hi_iQBOXrCjAIC72TNbFHK7ENmm9JN9GGxiZMZH1RoxkL30qrJXFV56Peg_7TYzu3CiYyqAgk"
              alt="Artisan Pizza"
              referrerPolicy="no-referrer"
            />
            <div className="absolute -bottom-6 -left-6 z-20 bg-surface-container-high p-6 rounded-2xl border border-outline-variant/20 shadow-xl">
              <p className="font-headline font-black text-3xl text-secondary-container">PRIMEIRAPIZZA</p>
              <p className="font-label text-xs uppercase tracking-tighter opacity-70">Use o cupom na primeira compra</p>
            </div>
          </motion.div>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-24 bg-surface-container-low">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: Zap, title: "Fast Delivery", desc: "Seu pedido chega quentinho em tempo recorde.", color: "border-primary-container" },
              { icon: ShieldCheck, title: "Real Quality", desc: "Ingredientes premium e massa de longa fermentação.", color: "border-secondary-container" },
              { icon: Heart, title: "Made with Care", desc: "Cada pizza é montada artesanalmente com carinho.", color: "border-tertiary-container" },
              { icon: MapPin, title: "Local Focus", desc: "Orgulho de ser a pizzaria favorita de Angra.", color: "border-outline" },
            ].map((feature, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className={`bg-surface-container p-8 rounded-2xl border-b-4 ${feature.color}`}
              >
                <feature.icon className="text-4xl text-primary mb-4" size={32} />
                <h3 className="font-headline font-bold text-xl mb-2">{feature.title}</h3>
                <p className="text-on-surface-variant text-sm">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Menu Section */}
      <section className="py-24 bg-surface" id="menu">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
            <div>
              <h2 className="text-5xl font-headline font-black mb-4">Nosso Cardápio</h2>
              <p className="text-on-surface-variant max-w-md">Uma seleção divina para todos os paladares, do clássico ao extraordinário.</p>
            </div>
            <div className="flex flex-wrap gap-4">
              {['Todos', 'Tradicionais', 'Especiais', 'Premium'].map((cat) => (
                <button 
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-6 py-2 rounded-full font-label text-sm transition-all ${activeCategory === cat ? 'bg-primary-container text-white' : 'bg-surface-container-high border border-outline-variant/20 hover:bg-surface-container-highest'}`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <motion.div 
            layout
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
          >
            <AnimatePresence mode="popLayout">
              {filteredMenu.map((item) => (
                <motion.div 
                  key={item.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="group bg-surface-container-high rounded-2xl overflow-hidden hover:shadow-2xl transition-all duration-300"
                >
                  <div className="h-48 overflow-hidden">
                    <img 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
                      src={item.image} 
                      alt={item.name}
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="p-6">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-headline font-bold text-xl">{item.name}</h4>
                      <span className="text-secondary-container font-label font-bold">R$ {item.price}</span>
                    </div>
                    <p className="text-on-surface-variant text-sm leading-relaxed mb-4">{item.description}</p>
                    {item.tag && (
                      <span className={`inline-block px-2 py-1 rounded text-[10px] font-black uppercase tracking-widest ${item.tag === 'Premium' ? 'bg-primary-container/20 text-primary' : 'bg-secondary-container/10 text-secondary-container'}`}>
                        {item.tag}
                      </span>
                    )}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        </div>
      </section>

      {/* Promotion Banner */}
      <section className="py-12 bg-surface" id="promoções">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="relative bg-primary-container rounded-3xl p-8 md:p-16 overflow-hidden flex flex-col md:flex-row items-center gap-12"
          >
            <div className="absolute top-0 right-0 w-1/3 h-full bg-black/10 -skew-x-12 translate-x-1/2"></div>
            <div className="relative z-10 space-y-6 max-w-xl text-center md:text-left">
              <h2 className="text-4xl md:text-6xl font-headline font-black text-white leading-tight">Promoção da noite!</h2>
              <p className="text-2xl text-white/90 font-medium">2 pizzas grandes + refrigerante 2L por apenas <span className="text-secondary-container text-4xl font-black">R$ 89,90</span></p>
              <button 
                onClick={() => window.open(WHATSAPP_LINK, '_blank')}
                className="bg-white text-primary-container px-10 py-4 rounded-xl font-headline font-extrabold hover:bg-secondary-container transition-colors shadow-lg"
              >
                APROVEITAR AGORA
              </button>
            </div>
            <div className="relative z-10">
              <img 
                className="rounded-2xl shadow-2xl scale-110 md:rotate-6" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuDCyQ03UPceTUN3nNd1g2YiQGlWk8PjudEizxn_aJ-5i_SmZ-thsIzZgVKaVODAAGZknFoe9PvEmXDxM8UM34aDbXNhaNURdjf4lXNfkqR4LwjbhIpgWU8ePHNBH5ZkH5mJTHSLVQxyWa6td-3gFXx_SPyvBt-XWKwvfHKyvFUTYXNJnEjkHfL4Qy_YCj3pfoKhXNZE8qpKVPY7F_IhAvvLZOqkuL6DGkIVTkAky5GM1VSfwOFiZJkEkMOY3fIG6EUC5n4P45PTHlI" 
                alt="Promotion"
                referrerPolicy="no-referrer"
              />
            </div>
          </motion.div>
        </div>
      </section>

      {/* How it Works */}
      <section className="py-24 bg-surface-container-lowest">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-4xl font-headline font-black text-center mb-16">Como pedir sua Divina</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { icon: MenuIcon, step: "1. Escolha", desc: "Navegue pelo nosso cardápio e escolha seus sabores favoritos." },
              { icon: ShoppingCart, step: "2. Peça", desc: "Peça pelo iFood ou WhatsApp de forma rápida e segura." },
              { icon: Truck, step: "3. Receba", desc: "Em até 45 minutos sua pizza chega quentinha na sua porta." },
            ].map((item, idx) => (
              <div key={idx} className="text-center group">
                <div className="w-20 h-20 bg-surface-container-high rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-primary-container transition-colors duration-300">
                  <item.icon size={32} className="text-primary-container group-hover:text-white transition-colors" />
                </div>
                <h4 className="font-headline font-bold text-2xl mb-4">{item.step}</h4>
                <p className="text-on-surface-variant">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-surface">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-4xl font-headline font-black text-center mb-16">Quem prova, pede de novo</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { name: "Marina Silva", role: "Cliente fiel no Camorim", text: "A melhor pizza de Angra sem dúvidas. A massa é levíssima e o recheio é muito caprichado. Chegou super rápido!" },
              { name: "Ricardo Oliveira", role: "Amante de pizza", text: "Sempre peço a Divina Especial. É de outro mundo! O atendimento pelo WhatsApp é excelente e muito prático." },
              { name: "Ana Costa", role: "Moradora de Angra", text: "Surpreendente! Ingredientes de primeira e a pizza chega realmente quente. O cupom de primeira compra é ótimo." },
            ].map((testimonial, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                className="bg-surface-container-high p-8 rounded-2xl relative"
              >
                <Quote className="text-primary-container absolute -top-4 left-8 opacity-20" size={48} />
                <p className="text-on-surface-variant italic mb-6 pt-4">"{testimonial.text}"</p>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-outline-variant flex items-center justify-center text-white font-bold">
                    {testimonial.name[0]}
                  </div>
                  <div>
                    <p className="font-bold">{testimonial.name}</p>
                    <p className="text-xs text-on-surface-variant">{testimonial.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Location Section */}
      <section className="py-24 bg-surface-container-low" id="entrega">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
          >
            <h2 className="text-4xl font-headline font-black mb-6">Onde estamos</h2>
            <p className="text-on-surface-variant text-lg leading-relaxed mb-8">
              Nossa base fica no coração do <span className="text-primary font-bold">Camorim Grande</span>. Entregamos com agilidade em toda a região vizinha, garantindo que sua pizza chegue perfeita.
            </p>
            <ul className="space-y-4">
              {['Camorim Grande e Pequeno', 'Jacuecanga', 'Verolme', 'Monsenhor Nunes'].map((loc) => (
                <li key={loc} className="flex items-center gap-3">
                  <CheckCircle2 size={20} className="text-primary" />
                  <span>{loc}</span>
                </li>
              ))}
            </ul>
          </motion.div>
          <div className="rounded-3xl overflow-hidden h-[400px] shadow-2xl grayscale contrast-125 border border-outline-variant/30">
            <img 
              className="w-full h-full object-cover" 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuCAQEtvzQOxJxvzzksIYdn_KN_aBaK3UIsbE7u4u7P-wYsbVzv0BZycUfyYzVF5JRpy_wekMnpIvo0EZBWXL71Y27us4PQbtHy-wyqfs4Owj-SLONfEjw9sxvYiLMhqUS2-tBDJvXM68lAkqmzyXhqTQVEyXCD8Nv8GqlcnTXj_paDPfYBlLdK5VxfGOm_poDI0MDCa_AgBNiJb0Dx_eQcMTyeZWy9AIR9T7MiRTh3JSy3leIQ0TVffEFu5bmXjVA7M7NrUtVE2RC4" 
              alt="Map"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-surface-container-lowest border-t border-outline-variant/10 py-12" id="sobre-nós">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="text-center md:text-left">
            <span className="text-2xl font-black text-primary-container italic font-headline">Divina Pizza Angra</span>
            <p className="text-sm text-on-surface-variant max-w-xs mt-2">A tradição da pizza artesanal no litoral de Angra dos Reis.</p>
          </div>
          <div className="flex gap-8">
            <a href="#" className="text-sm text-on-surface-variant hover:text-primary transition-colors">Termos de Uso</a>
            <a href="#" className="text-sm text-on-surface-variant hover:text-primary transition-colors">Privacidade</a>
            <a href="#" className="text-sm text-on-surface-variant hover:text-primary transition-colors">Trabalhe Conosco</a>
          </div>
          <p className="text-sm text-on-surface-variant">© 2024 Divina Pizza Angra. Todos os direitos reservados.</p>
        </div>
      </footer>

      {/* Floating WhatsApp Button */}
      <button 
        onClick={() => window.open(WHATSAPP_LINK, '_blank')}
        className="fixed bottom-8 right-8 z-[100] bg-tertiary-container text-on-tertiary-container p-4 rounded-full shadow-2xl hover:scale-110 transition-transform flex items-center gap-3 group"
      >
        <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 font-bold font-label whitespace-nowrap">
          Pedir agora
        </span>
        <MessageCircle size={32} />
      </button>
    </div>
  );
}
