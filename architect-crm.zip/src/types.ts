import { Timestamp } from 'firebase/firestore';

export type FunnelStatus = 'Novo' | 'Em Atendimento' | 'Proposta' | 'Fechado';

export interface Customer {
  id?: string;
  name: string;
  email?: string;
  phone: string;
  status: FunnelStatus;
  tags?: string[];
  lastInteraction?: Timestamp;
  notes?: string;
  uid: string;
}

export interface QuickReply {
  id?: string;
  title: string;
  content: string;
  uid: string;
}
