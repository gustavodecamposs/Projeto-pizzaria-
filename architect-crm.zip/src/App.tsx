import React, { useState, useEffect } from 'react';
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut, 
  User 
} from 'firebase/auth';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  doc, 
  deleteDoc,
  Timestamp,
  orderBy,
  getDocFromServer
} from 'firebase/firestore';
import { 
  LayoutDashboard, 
  Users, 
  Kanban, 
  Zap, 
  Settings, 
  LogOut, 
  Plus, 
  Search, 
  Bell, 
  MessageSquare,
  AlertCircle,
  ExternalLink,
  Filter,
  MoreVertical,
  ChevronLeft,
  ChevronRight,
  Clock,
  Tag
} from 'lucide-react';
import { auth, db } from './firebase';
import { Customer, FunnelStatus, QuickReply } from './types';
import { cn } from './lib/utils';
import { Toaster, toast } from 'sonner';

// --- Components ---

const SidebarItem = ({ icon: Icon, label, active, onClick }: { icon: any, label: string, active?: boolean, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className={cn(
      "flex items-center space-x-3 w-full px-4 py-3 rounded-md transition-all duration-200 font-manrope text-xs uppercase tracking-widest font-bold",
      active 
        ? "bg-white text-[#005C72] shadow-sm translate-x-1" 
        : "text-slate-600 hover:text-[#005C72] hover:bg-white/50"
    )}
  >
    <Icon size={18} />
    <span>{label}</span>
  </button>
);

const StatusBadge = ({ status }: { status: FunnelStatus }) => {
  const colors = {
    'Novo': 'bg-blue-100 text-blue-700',
    'Em Atendimento': 'bg-amber-100 text-amber-700',
    'Proposta': 'bg-purple-100 text-purple-700',
    'Fechado': 'bg-emerald-100 text-emerald-700'
  };
  return (
    <span className={cn("px-2 py-1 rounded-full text-[10px] font-bold uppercase", colors[status])}>
      {status}
    </span>
  );
};

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'dashboard' | 'customers' | 'kanban' | 'replies'>('dashboard');
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [replies, setReplies] = useState<QuickReply[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [isReplyModalOpen, setIsReplyModalOpen] = useState(false);
  const [editingReply, setEditingReply] = useState<QuickReply | null>(null);

  // ... existing code ...

  const handleSaveReply = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user) return;

    const formData = new FormData(e.currentTarget);
    const data = {
      title: formData.get('title') as string,
      content: formData.get('content') as string,
      uid: user.uid
    };

    try {
      if (editingReply?.id) {
        await updateDoc(doc(db, 'quickReplies', editingReply.id), data);
        toast.success("Resposta atualizada!");
      } else {
        await addDoc(collection(db, 'quickReplies'), data);
        toast.success("Resposta adicionada!");
      }
      setIsReplyModalOpen(false);
      setEditingReply(null);
    } catch (err) {
      toast.error("Erro ao salvar resposta.");
    }
  };

  const deleteReply = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'quickReplies', id));
      toast.success("Resposta removida!");
    } catch (err) {
      toast.error("Erro ao remover resposta.");
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setLoading(false);
      if (u) {
        // Test connection
        const testConnection = async () => {
          try {
            await getDocFromServer(doc(db, 'test', 'connection'));
          } catch (error: any) {
            if (error.message?.includes('the client is offline')) {
              toast.error("Erro de conexão com o Firebase. Verifique as regras de segurança.");
            }
          }
        };
        testConnection();
      }
    });
    return () => unsubscribe();
  }, []);

  // Data Listeners
  useEffect(() => {
    if (!user) return;

    const qCustomers = query(
      collection(db, 'customers'), 
      where('uid', '==', user.uid),
      orderBy('name', 'asc')
    );
    const unsubCustomers = onSnapshot(qCustomers, (snapshot) => {
      setCustomers(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Customer)));
    }, (err) => {
      console.error("Firestore Error (Customers):", err);
      toast.error("Erro ao carregar clientes.");
    });

    const qReplies = query(collection(db, 'quickReplies'), where('uid', '==', user.uid));
    const unsubReplies = onSnapshot(qReplies, (snapshot) => {
      setReplies(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as QuickReply)));
    }, (err) => {
      console.error("Firestore Error (Replies):", err);
    });

    return () => {
      unsubCustomers();
      unsubReplies();
    };
  }, [user]);

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      toast.success("Bem-vindo!");
    } catch (err) {
      toast.error("Erro ao fazer login.");
    }
  };

  const handleLogout = () => signOut(auth);

  const openWhatsApp = (phone: string) => {
    const cleanPhone = phone.replace(/\D/g, '');
    window.open(`https://wa.me/${cleanPhone}`, '_blank');
  };

  const handleSaveCustomer = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user) return;

    const formData = new FormData(e.currentTarget);
    const data = {
      name: formData.get('name') as string,
      phone: formData.get('phone') as string,
      email: formData.get('email') as string,
      status: formData.get('status') as FunnelStatus,
      notes: formData.get('notes') as string,
      uid: user.uid,
      lastInteraction: Timestamp.now()
    };

    try {
      if (editingCustomer?.id) {
        await updateDoc(doc(db, 'customers', editingCustomer.id), data);
        toast.success("Cliente atualizado!");
      } else {
        await addDoc(collection(db, 'customers'), data);
        toast.success("Cliente adicionado!");
      }
      setIsModalOpen(false);
      setEditingCustomer(null);
    } catch (err) {
      toast.error("Erro ao salvar cliente.");
    }
  };

  if (loading) return (
    <div className="h-screen w-full flex items-center justify-center bg-surface">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
    </div>
  );

  if (!user) return (
    <div className="min-h-screen flex items-center justify-center bg-surface p-6">
      <div className="max-w-md w-full bg-white rounded-xl shadow-lg p-8 text-center">
        <div className="flex justify-center mb-6">
          <div className="p-4 bg-primary-container rounded-2xl text-white">
            <LayoutDashboard size={48} />
          </div>
        </div>
        <h1 className="text-3xl font-black text-primary font-headline mb-2">Architect CRM</h1>
        <p className="text-slate-500 mb-8">Gestão de clientes e WhatsApp para arquitetos.</p>
        <button 
          onClick={handleLogin}
          className="w-full py-4 px-6 bg-primary text-white font-bold rounded-md shadow-md hover:shadow-lg transition-all flex items-center justify-center space-x-2"
        >
          <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-5 h-5" alt="Google" />
          <span>Entrar com Google</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-surface font-body text-on-surface">
      <Toaster position="top-right" />
      
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 h-screen w-64 bg-[#eceef0] flex flex-col p-4 space-y-2 z-40">
        <div className="mb-8 px-4 py-2">
          <h1 className="text-lg font-black text-[#005C72] font-headline">The Architect</h1>
          <p className="font-manrope text-[10px] uppercase tracking-widest font-bold text-slate-500">WhatsApp Management</p>
        </div>
        
        <nav className="flex-grow space-y-1">
          <SidebarItem icon={LayoutDashboard} label="Dashboard" active={view === 'dashboard'} onClick={() => setView('dashboard')} />
          <SidebarItem icon={Users} label="Clientes" active={view === 'customers'} onClick={() => setView('customers')} />
          <SidebarItem icon={Kanban} label="Funil Kanban" active={view === 'kanban'} onClick={() => setView('kanban')} />
          <SidebarItem icon={Zap} label="Respostas Rápidas" active={view === 'replies'} onClick={() => setView('replies')} />
        </nav>

        <div className="pt-4 mt-auto border-t border-slate-200/50">
          <button 
            onClick={handleLogout}
            className="flex items-center space-x-3 text-slate-600 px-4 py-3 hover:text-error transition-all w-full font-manrope text-xs uppercase tracking-widest font-bold"
          >
            <LogOut size={18} />
            <span>Sair</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="ml-64 flex-grow flex flex-col">
        {/* Header */}
        <header className="sticky top-0 z-50 w-full h-16 bg-slate-50 flex justify-between items-center px-8 border-b border-slate-200">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
              <input 
                type="text" 
                placeholder="Buscar clientes..." 
                className="pl-10 pr-4 py-2 bg-[#eceef0] border-none rounded-md focus:ring-2 focus:ring-[#005C72] text-sm w-64 transition-all"
              />
            </div>
          </div>
          
          <div className="flex items-center space-x-6">
            <button className="p-2 text-slate-500 hover:bg-white/50 transition-colors rounded-full relative">
              <Bell size={20} />
              <span className="absolute top-1 right-1 w-2 h-2 bg-error rounded-full border-2 border-white"></span>
            </button>
            <div className="h-8 w-[1px] bg-slate-200"></div>
            <div className="flex items-center space-x-3">
              <div className="text-right">
                <p className="text-sm font-bold text-[#005C72] leading-none">{user.displayName}</p>
                <p className="text-[10px] text-slate-500 uppercase tracking-tighter">Arquiteto</p>
              </div>
              <img 
                src={user.photoURL || "https://ui-avatars.com/api/?name=" + user.displayName} 
                className="w-10 h-10 rounded-full object-cover ring-2 ring-white" 
                alt="Profile" 
              />
            </div>
          </div>
        </header>

        <div className="p-8">
          {view === 'dashboard' && (
            <div className="space-y-8">
              <div className="mb-10">
                <h2 className="font-headline text-4xl font-extrabold text-on-surface tracking-tight mb-2">Workspace Overview</h2>
                <p className="text-on-surface-variant font-medium">Acompanhamento de precisão para seus leads e comunicações.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <DashboardCard icon={Plus} label="Novos Leads" value={customers.filter(c => c.status === 'Novo').length} color="primary" />
                <DashboardCard icon={Clock} label="Em Atendimento" value={customers.filter(c => c.status === 'Em Atendimento').length} color="secondary" />
                <DashboardCard icon={ExternalLink} label="Propostas" value={customers.filter(c => c.status === 'Proposta').length} color="tertiary" />
                <DashboardCard icon={AlertCircle} label="Esquecidos" value={customers.filter(c => {
                  if (!c.lastInteraction) return true;
                  const diff = Date.now() - c.lastInteraction.toMillis();
                  return diff > 3 * 24 * 60 * 60 * 1000;
                }).length} color="error" />
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-6">
                  <h4 className="font-headline text-xl font-bold text-on-surface">Atividade Recente</h4>
                  <div className="bg-surface-container-low p-2 rounded-2xl space-y-2">
                    {customers.slice(0, 5).map(customer => (
                      <div key={customer.id} className="bg-white p-4 rounded-xl flex items-center justify-between hover:bg-surface-container-high transition-colors">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 rounded-full bg-secondary-container flex items-center justify-center text-primary font-bold">
                            {customer.name.charAt(0)}
                          </div>
                          <div>
                            <p className="text-sm font-bold text-on-surface">{customer.name}</p>
                            <p className="text-xs text-on-surface-variant">Status: {customer.status}</p>
                          </div>
                        </div>
                        <button 
                          onClick={() => openWhatsApp(customer.phone)}
                          className="p-2 bg-emerald-100 text-emerald-700 rounded-lg hover:bg-emerald-200 transition-colors"
                        >
                          <MessageSquare size={18} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-6">
                  <h4 className="font-headline text-xl font-bold text-on-surface">Ações Rápidas</h4>
                  <div className="space-y-3">
                    <button 
                      onClick={() => { setEditingCustomer(null); setIsModalOpen(true); }}
                      className="w-full py-4 px-6 bg-primary text-white rounded-xl flex items-center justify-between group hover:shadow-xl transition-all"
                    >
                      <span className="font-bold">Novo Lead</span>
                      <Plus size={20} />
                    </button>
                    <button 
                      onClick={() => setView('kanban')}
                      className="w-full py-4 px-6 bg-white border border-slate-200 rounded-xl flex items-center justify-between group hover:border-primary transition-all"
                    >
                      <span className="font-bold">Ver Funil</span>
                      <Kanban size={20} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {view === 'customers' && (
            <div className="space-y-6">
              <div className="flex justify-between items-end">
                <div>
                  <h2 className="font-headline text-4xl font-extrabold text-on-surface tracking-tight mb-2">Clientes</h2>
                  <p className="text-on-surface-variant font-medium">Gerencie seus leads e relacionamentos.</p>
                </div>
                <button 
                  onClick={() => { setEditingCustomer(null); setIsModalOpen(true); }}
                  className="bg-primary text-white px-6 py-2.5 rounded-md font-bold text-sm shadow-lg hover:brightness-110 transition-all flex items-center space-x-2"
                >
                  <Plus size={18} />
                  <span>Adicionar Cliente</span>
                </button>
              </div>

              <div className="bg-white rounded-xl shadow-sm overflow-hidden border border-slate-200">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200">
                      <th className="px-6 py-4 text-[11px] uppercase tracking-widest font-bold text-slate-500">Nome</th>
                      <th className="px-6 py-4 text-[11px] uppercase tracking-widest font-bold text-slate-500">Telefone</th>
                      <th className="px-6 py-4 text-[11px] uppercase tracking-widest font-bold text-slate-500">Status</th>
                      <th className="px-6 py-4 text-[11px] uppercase tracking-widest font-bold text-slate-500">Última Interação</th>
                      <th className="px-6 py-4 text-[11px] uppercase tracking-widest font-bold text-slate-500 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {customers.map(customer => (
                      <tr key={customer.id} className="hover:bg-slate-50 transition-colors group">
                        <td className="px-6 py-5">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center font-bold text-primary">
                              {customer.name.charAt(0)}
                            </div>
                            <div>
                              <p className="font-semibold text-on-surface">{customer.name}</p>
                              <p className="text-xs text-on-surface-variant">{customer.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-5 font-medium text-sm text-slate-600">{customer.phone}</td>
                        <td className="px-6 py-5"><StatusBadge status={customer.status} /></td>
                        <td className="px-6 py-5 text-sm text-slate-500">
                          {customer.lastInteraction?.toDate().toLocaleDateString('pt-BR')}
                        </td>
                        <td className="px-6 py-5 text-right space-x-2">
                          <button 
                            onClick={() => openWhatsApp(customer.phone)}
                            className="p-2 bg-emerald-50 text-emerald-600 rounded-md hover:bg-emerald-100 transition-colors"
                          >
                            <MessageSquare size={16} />
                          </button>
                          <button 
                            onClick={() => { setEditingCustomer(customer); setIsModalOpen(true); }}
                            className="p-2 bg-slate-50 text-slate-600 rounded-md hover:bg-slate-100 transition-colors"
                          >
                            <MoreVertical size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {view === 'kanban' && (
            <div className="space-y-6">
              <h2 className="font-headline text-4xl font-extrabold text-on-surface tracking-tight">Funil Kanban</h2>
              <div className="flex space-x-6 overflow-x-auto pb-6 min-h-[600px]">
                {(['Novo', 'Em Atendimento', 'Proposta', 'Fechado'] as FunnelStatus[]).map(status => (
                  <div key={status} className="w-80 flex-shrink-0 flex flex-col space-y-4">
                    <div className="flex items-center justify-between px-2">
                      <div className="flex items-center space-x-2">
                        <div className={cn("w-2 h-2 rounded-full", 
                          status === 'Novo' ? 'bg-blue-500' : 
                          status === 'Em Atendimento' ? 'bg-amber-500' : 
                          status === 'Proposta' ? 'bg-purple-500' : 'bg-emerald-500'
                        )} />
                        <h3 className="text-xs uppercase tracking-widest font-bold text-slate-500">{status}</h3>
                        <span className="bg-slate-200 text-slate-600 px-2 py-0.5 rounded text-[10px] font-bold">
                          {customers.filter(c => c.status === status).length}
                        </span>
                      </div>
                    </div>
                    <div className="bg-slate-100 rounded-xl p-3 flex-grow space-y-3">
                      {customers.filter(c => c.status === status).map(customer => (
                        <div 
                          key={customer.id} 
                          onClick={() => { setEditingCustomer(customer); setIsModalOpen(true); }}
                          className="bg-white p-4 rounded-xl shadow-sm border border-slate-200 hover:shadow-md transition-all cursor-pointer"
                        >
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="text-sm font-bold text-on-surface">{customer.name}</h4>
                            <button onClick={(e) => { e.stopPropagation(); openWhatsApp(customer.phone); }}>
                              <MessageSquare size={14} className="text-emerald-500" />
                            </button>
                          </div>
                          <p className="text-xs text-slate-500 line-clamp-2 mb-3">{customer.notes || "Sem notas."}</p>
                          <div className="flex items-center justify-between mt-auto">
                            <div className="flex items-center space-x-1 text-[10px] text-slate-400">
                              <Clock size={10} />
                              <span>{customer.lastInteraction?.toDate().toLocaleDateString()}</span>
                            </div>
                            <div className="flex -space-x-2">
                              <div className="w-6 h-6 rounded-full bg-primary-container text-white text-[10px] flex items-center justify-center border-2 border-white">
                                {customer.name.charAt(0)}
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {view === 'replies' && (
            <div className="space-y-6">
              <div className="flex justify-between items-end">
                <div>
                  <h2 className="font-headline text-4xl font-extrabold text-on-surface tracking-tight mb-2">Respostas Rápidas</h2>
                  <p className="text-on-surface-variant font-medium">Templates de mensagens para agilizar seu atendimento.</p>
                </div>
                <button 
                  onClick={() => { setEditingReply(null); setIsReplyModalOpen(true); }}
                  className="bg-primary text-white px-6 py-2.5 rounded-md font-bold text-sm shadow-lg hover:brightness-110 transition-all flex items-center space-x-2"
                >
                  <Plus size={18} />
                  <span>Nova Resposta</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {replies.map(reply => (
                  <div key={reply.id} className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 hover:border-primary transition-all group">
                    <div className="flex justify-between items-start mb-4">
                      <h4 className="font-bold text-primary">{reply.title}</h4>
                      <div className="flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => { setEditingReply(reply); setIsReplyModalOpen(true); }} className="p-1 text-slate-400 hover:text-primary">
                          <Settings size={14} />
                        </button>
                        <button onClick={() => deleteReply(reply.id!)} className="p-1 text-slate-400 hover:text-error">
                          <AlertCircle size={14} />
                        </button>
                      </div>
                    </div>
                    <p className="text-sm text-slate-600 line-clamp-4 bg-slate-50 p-3 rounded-lg border border-slate-100 italic">
                      "{reply.content}"
                    </p>
                    <button 
                      onClick={() => {
                        navigator.clipboard.writeText(reply.content);
                        toast.success("Copiado para a área de transferência!");
                      }}
                      className="mt-4 w-full py-2 text-[10px] uppercase tracking-widest font-bold text-primary hover:bg-primary-container hover:text-white rounded-md transition-all border border-primary/20"
                    >
                      Copiar Mensagem
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Quick Reply Modal */}
      {isReplyModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h3 className="text-xl font-bold text-primary">
                {editingReply ? 'Editar Resposta' : 'Nova Resposta'}
              </h3>
              <button onClick={() => setIsReplyModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <ChevronLeft size={24} />
              </button>
            </div>
            <form onSubmit={handleSaveReply} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-widest font-bold text-slate-500">Título do Template</label>
                <input 
                  name="title" 
                  defaultValue={editingReply?.title} 
                  required 
                  placeholder="Ex: Saudação Inicial"
                  className="w-full px-4 py-3 bg-slate-50 border-none rounded-lg focus:ring-2 focus:ring-primary"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-widest font-bold text-slate-500">Conteúdo da Mensagem</label>
                <textarea 
                  name="content" 
                  defaultValue={editingReply?.content} 
                  required 
                  rows={6} 
                  placeholder="Olá! Como posso ajudar no seu projeto hoje?"
                  className="w-full px-4 py-3 bg-slate-50 border-none rounded-lg focus:ring-2 focus:ring-primary"
                />
              </div>
              <div className="pt-4 flex space-x-3">
                <button 
                  type="button" 
                  onClick={() => setIsReplyModalOpen(false)}
                  className="flex-1 py-3 px-4 bg-slate-100 text-slate-600 font-bold rounded-lg hover:bg-slate-200"
                >
                  Cancelar
                </button>
                <button 
                  type="submit" 
                  className="flex-1 py-3 px-4 bg-primary text-white font-bold rounded-lg hover:brightness-110 shadow-lg"
                >
                  Salvar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Customer Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h3 className="text-xl font-bold text-primary">
                {editingCustomer ? 'Editar Cliente' : 'Novo Cliente'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <ChevronLeft size={24} />
              </button>
            </div>
            <form onSubmit={handleSaveCustomer} className="p-6 space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-widest font-bold text-slate-500">Nome Completo</label>
                <input 
                  name="name" 
                  defaultValue={editingCustomer?.name} 
                  required 
                  className="w-full px-4 py-3 bg-slate-50 border-none rounded-lg focus:ring-2 focus:ring-primary"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-widest font-bold text-slate-500">WhatsApp</label>
                  <input 
                    name="phone" 
                    defaultValue={editingCustomer?.phone} 
                    required 
                    placeholder="5511999999999"
                    className="w-full px-4 py-3 bg-slate-50 border-none rounded-lg focus:ring-2 focus:ring-primary"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-widest font-bold text-slate-500">Status</label>
                  <select 
                    name="status" 
                    defaultValue={editingCustomer?.status || 'Novo'} 
                    className="w-full px-4 py-3 bg-slate-50 border-none rounded-lg focus:ring-2 focus:ring-primary"
                  >
                    <option value="Novo">Novo</option>
                    <option value="Em Atendimento">Em Atendimento</option>
                    <option value="Proposta">Proposta</option>
                    <option value="Fechado">Fechado</option>
                  </select>
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-widest font-bold text-slate-500">E-mail</label>
                <input 
                  name="email" 
                  type="email" 
                  defaultValue={editingCustomer?.email} 
                  className="w-full px-4 py-3 bg-slate-50 border-none rounded-lg focus:ring-2 focus:ring-primary"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] uppercase tracking-widest font-bold text-slate-500">Notas</label>
                <textarea 
                  name="notes" 
                  defaultValue={editingCustomer?.notes} 
                  rows={3} 
                  className="w-full px-4 py-3 bg-slate-50 border-none rounded-lg focus:ring-2 focus:ring-primary"
                />
              </div>
              <div className="pt-4 flex space-x-3">
                <button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-3 px-4 bg-slate-100 text-slate-600 font-bold rounded-lg hover:bg-slate-200"
                >
                  Cancelar
                </button>
                <button 
                  type="submit" 
                  className="flex-1 py-3 px-4 bg-primary text-white font-bold rounded-lg hover:brightness-110 shadow-lg"
                >
                  Salvar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

function DashboardCard({ icon: Icon, label, value, color }: { icon: any, label: string, value: number, color: string }) {
  const colorClasses = {
    primary: 'bg-primary-container text-white',
    secondary: 'bg-secondary-container text-primary',
    tertiary: 'bg-tertiary-fixed text-tertiary',
    error: 'bg-error-container text-error'
  };
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border-b-2 border-transparent hover:border-primary transition-all group">
      <div className="flex justify-between items-start mb-4">
        <div className={cn("p-2 rounded-lg transition-colors", colorClasses[color as keyof typeof colorClasses])}>
          <Icon size={20} />
        </div>
      </div>
      <p className="text-[10px] uppercase tracking-widest text-slate-500 mb-1">{label}</p>
      <h3 className="text-3xl font-bold text-on-surface">{value}</h3>
    </div>
  );
}
